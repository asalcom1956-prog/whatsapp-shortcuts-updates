export function getReply(shortcuts, code) {
    const found = shortcuts.find(s => s.code === code);
    if (!found) return "❌ اختصار غير موجود";
    return found.text;
}