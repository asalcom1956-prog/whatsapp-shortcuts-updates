export function getReply(shortcuts, code) {
    const found = shortcuts.find(s => s.code === code);

    if (!found) return "❌ No shortcut found for this code.";

    return found.text;
}
