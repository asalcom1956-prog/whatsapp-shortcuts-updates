import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

export function loadSession(sessionNumber) {
    const filePath = path.join(__dirname, `../data/session${sessionNumber}.json`);

    if (!fs.existsSync(filePath)) return [];

    const data = fs.readFileSync(filePath, "utf8");
    return JSON.parse(data);
}
