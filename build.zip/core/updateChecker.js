import axios from "axios";
import fs from "fs";
import AdmZip from "adm-zip";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

export async function checkForUpdates() {
    try {
        const configPath = path.join(__dirname, "../config/config.json");
        const config = JSON.parse(fs.readFileSync(configPath, "utf8"));

        console.log("🔍 Checking for updates...");

        const res = await axios.get(config.update_url);
        const server = res.data;

        if (!server.version) {
            console.log("❌ Invalid version.json structure.");
            return;
        }

        if (server.version === config.current_version) {
            console.log("✔ You have latest version:", config.current_version);
            return;
        }

        console.log(`⬆ New version available: ${server.version}`);
        console.log("⬇ Downloading update...");

        const zipFile = await axios.get(server.update_url, { responseType: "arraybuffer" });

        const zipPath = path.join(__dirname, "../update.zip");
        fs.writeFileSync(zipPath, zipFile.data);

        console.log("📦 Update downloaded, extracting...");

        const zip = new AdmZip(zipPath);
        zip.extractAllTo(path.join(__dirname, ".."), true);

        console.log("✔ Update installed.");

        config.current_version = server.version;
        fs.writeFileSync(configPath, JSON.stringify(config, null, 2));

        fs.unlinkSync(zipPath);
        console.log("🎉 Update complete!");

    } catch (err) {
        console.log("❌ Update failed:", err.message);
    }
}