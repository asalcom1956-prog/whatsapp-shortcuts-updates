import fs from "fs";
import path from "path";
import AdmZip from "adm-zip";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

function readJSON(filePath) {
    return JSON.parse(fs.readFileSync(filePath, "utf8"));
}

function writeJSON(filePath, data) {
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
}

function bumpVersion(version) {
    let [major, minor, patch] = version.split(".").map(Number);
    patch += 1;
    return `${major}.${minor}.${patch}`;
}

function zipDirectory(source, out) {
    const zip = new AdmZip();
    zip.addLocalFolder(source);
    zip.writeZip(out);
}

async function makeRelease() {
    const configPath = path.join(__dirname, "../config/config.json");
    const config = readJSON(configPath);

    const newVersion = bumpVersion(config.current_version);

    console.log("New RELEASE DONE");
    console.log("Old Version", config.current_version);
    console.log("New Version", newVersion);

    config.current_version = newVersion;
    writeJSON(configPath, config);

    console.log("📦 Creating build.zip...");
    const projectRoot = path.join(__dirname, "..");
    const zipPath = path.join(projectRoot, "build.zip");

    zipDirectory(projectRoot, zipPath);

    console.log("✔ build.zip DONE");

    // تحديث نسخة version.json للتحديثات
    const versionJson = {
        version: newVersion,
        update_url: "https://raw.githubusercontent.com/asalcom1956-prog/whatsapp-shortcuts-updates/main/build.zip",
        changes: "Automatic update generation"
    };

    const versionFilePath = path.join(projectRoot, "version.json");
    writeJSON(versionFilePath, versionJson);

    console.log("Done version.json NEW");
    console.log("READY TO UPLOAD GITHUB");
}

makeRelease();
