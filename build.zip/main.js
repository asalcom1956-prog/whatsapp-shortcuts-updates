import readline from "readline";
import { checkForUpdates } from "./core/updateChecker.js";
import { loadSession } from "./core/sessionManager.js";
import { getReply } from "./core/shortcutEngine.js";

console.clear();
console.log("🚀 WhatsApp Shortcut System Started");

// ✔ Check for updates on startup
await checkForUpdates();

// Simple CLI
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

rl.question("🔢 اختر الجلسة (1-5): ", (sessionNum) => {
    const shortcuts = loadSession(sessionNum);

    rl.question("⌨️ اكتب الاختصار: ", (code) => {
        const reply = getReply(shortcuts, code);
        console.log("\n📨 الرد:");
        console.log(reply);
        rl.close();
    });
});
